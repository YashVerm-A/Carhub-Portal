# 🚀 Week 6 Peer-Graded Assignment Solutions :- ✅ 😇 👇
## Follow the Below mentioned steps :- 👇 ✅

# TASK 1 :- 👇
## LINK :- `https://github.com/digital-installer/xrwvm-fullstack_developer_capstone`

# TASK 2 :- 👇
## TITLE :- `Django server running.`
<img width="719" alt="django_server" src="https://github.com/Uday-Pratap-hub/IBM-Full-Stack-Application-Development-Capstone-Project/assets/67860426/52250e41-6f43-4244-a048-0684d65e5a17">

# TASK 3 :- 👇
## TITLE :- `"About us" page of the Django Application`
<img width="1416" alt="about_us" src="https://github.com/Uday-Pratap-hub/IBM-Full-Stack-Application-Development-Capstone-Project/assets/67860426/f781717c-e39b-42b6-afef-b7379ead5b7b">

# TASK 4 :- 👇
## TITLE :- `"Contact us" page of the Django Application`
<img width="1163" alt="contact_us" src="https://github.com/Uday-Pratap-hub/IBM-Full-Stack-Application-Development-Capstone-Project/assets/67860426/1e6d8b72-a8d5-40ff-8b22-b4a573fbd2d7">

# TASK 5 :- 👇
## TITLE :- `"Login" page of the Django Application`
<img width="1420" alt="login" src="https://github.com/Uday-Pratap-hub/IBM-Full-Stack-Application-Development-Capstone-Project/assets/67860426/5ffc237d-ec71-4d7e-bf6d-85d2a71069f5">

# TASK 6 :- 👇
## TITLE :- `"Logout Alert" of the Django Application`
<img width="1034" alt="logout" src="https://github.com/Uday-Pratap-hub/IBM-Full-Stack-Application-Development-Capstone-Project/assets/67860426/ff80b062-108f-4088-9ff1-1f85ec8e4503">

# TASK 7 :- 👇
## TITLE :- `"Sign Up" page of the Django Application`
<img width="1215" alt="sign-up" src="https://github.com/Uday-Pratap-hub/IBM-Full-Stack-Application-Development-Capstone-Project/assets/67860426/0083b876-d741-4d05-a912-a407741e7a29">

# TASK 8 :- 👇
## TITLE :- `Showing dealer reviews through the Express-Mongo application.`
<img width="1010" alt="dealer_review" src="https://github.com/Uday-Pratap-hub/IBM-Full-Stack-Application-Development-Capstone-Project/assets/67860426/fcde7aa6-f848-4e88-a481-2dcf8bde6037">

# TASK 9 :- 👇
## TITLE :- `Showing all dealers through the Express-Mongo application endpoint.`
<img width="1004" alt="dealerships" src="https://github.com/Uday-Pratap-hub/IBM-Full-Stack-Application-Development-Capstone-Project/assets/67860426/168f6c6f-5cb7-4a31-81ff-4954b16e2ec9">

# TASK 10 :- 👇
## TITLE :- `Dealer details through the Express-Mongo application.`
<img width="1004" alt="dealer_details" src="https://github.com/Uday-Pratap-hub/IBM-Full-Stack-Application-Development-Capstone-Project/assets/67860426/75c1183f-320e-4ae3-849a-5e3f495a0bf7">

# TASK 11 :- 👇
## TITLE :- `Showing all dealers in Kansas through the Express-Mongo application.`
<img width="1013" alt="kansasDealers" src="https://github.com/Uday-Pratap-hub/IBM-Full-Stack-Application-Development-Capstone-Project/assets/67860426/37a01289-16bb-4af1-abb3-50e2b828ad8f">

# TASK 12 :- 👇
## TITLE :- `Showing the root user login on the admin page.`
<img width="1395" alt="admin_login" src="https://github.com/Uday-Pratap-hub/IBM-Full-Stack-Application-Development-Capstone-Project/assets/67860426/5b8416a4-b9cb-4ed2-8c9b-c5f536b2becb">

# TASK 13 :- 👇
## TITLE :- `Showing the root user logged out from the admin page`
<img width="1029" alt="admin_logout" src="https://github.com/Uday-Pratap-hub/IBM-Full-Stack-Application-Development-Capstone-Project/assets/67860426/72f7809b-2f17-45bc-8f0a-7538457a343e">

# TASK 14 :- 👇
## TITLE :- `showing car makes (after adding or populating the car makes) from the admin pa`
<img width="1389" alt="cars" src="https://github.com/Uday-Pratap-hub/IBM-Full-Stack-Application-Development-Capstone-Project/assets/67860426/5a0868b3-bcf5-463d-a323-d70c198b4af7">

# TASK 15 :- 👇
## TITLE :- `showing car models (after adding or populating the car makes) from`
<img width="1401" alt="car_models" src="https://github.com/Uday-Pratap-hub/IBM-Full-Stack-Application-Development-Capstone-Project/assets/67860426/7b3064e5-5400-44b4-ab07-48f333c5d487">

# TASK 16 :- 👇
## TITLE :- `showing the sentiment analyzer working through the deployed URL.`
<img width="919" alt="sentiment_analyzer" src="https://github.com/Uday-Pratap-hub/IBM-Full-Stack-Application-Development-Capstone-Project/assets/67860426/2ef9e474-c815-4465-a8f2-a3e98d675e82">

# TASK 17 :- 👇
## TITLE :- `showing the dealers on the home page of the Django application before logging in.`
<img width="1423" alt="get_dealers" src="https://github.com/Uday-Pratap-hub/IBM-Full-Stack-Application-Development-Capstone-Project/assets/67860426/09988908-835e-4137-be2e-0b6e9097795e">

# TASK 18 :- 👇
## TITLE :- `showing the dealers on the home page of the Django application after logging in.`
<img width="1436" alt="get_dealers_loggedin" src="https://github.com/Uday-Pratap-hub/IBM-Full-Stack-Application-Development-Capstone-Project/assets/67860426/acbb96bb-3ea4-4a91-885d-f5da325f4340">

# TASK 19 :- 👇
## TITLE :- `showing the dealers filtered by the State on the home page of t`
<img width="1436" alt="dealersbystate" src="https://github.com/Uday-Pratap-hub/IBM-Full-Stack-Application-Development-Capstone-Project/assets/67860426/68f5ffbc-791b-4493-a68a-fea762c9ab47">

# TASK 20 :- 👇
## TITLE :- `showing the selected dealer details on the dealer page along with the reviews`
<img width="1426" alt="dealer_id_reviews" src="https://github.com/Uday-Pratap-hub/IBM-Full-Stack-Application-Development-Capstone-Project/assets/67860426/3a16b5ac-ece5-49a8-88e9-6d3ca5ea5931">

# TASK 21 :- 👇
## TITLE :- `showing the “Post Review” page after adding the details before you submit.`
<img width="1430" alt="dealership_review_submission" src="https://github.com/Uday-Pratap-hub/IBM-Full-Stack-Application-Development-Capstone-Project/assets/67860426/1f54d53f-1c77-4f85-90c4-07c5ccce6d0e">

# TASK 22 :- 👇
## TITLE :- `showing the review you posted. The details should match with the`
<img width="1440" alt="added_review" src="https://github.com/Uday-Pratap-hub/IBM-Full-Stack-Application-Development-Capstone-Project/assets/67860426/f179c752-8134-41c8-a15b-24af289eadcc">

# TASK 23 :- 👇
## TITLE :- `successful implementation of CI/CD on GitHub.`
<img width="1392" alt="CICD" src="https://github.com/Uday-Pratap-hub/IBM-Full-Stack-Application-Development-Capstone-Project/assets/67860426/b70a45f7-7100-4ac5-966f-e35c4657ae0d">

# TASK 24 :- 👇
## LINK :- `https://akinbamigben-8000.theiadockernext-0-labs-prod-theiak8s-4-tor01.proxy.cognitiveclass.ai/`

# TASK 25 :- 👇
## TITLE :- `of the landing page opened through your deployment`
<img width="1426" alt="deployed_landingpage" src="https://github.com/Uday-Pratap-hub/IBM-Full-Stack-Application-Development-Capstone-Project/assets/67860426/7928976b-4f0f-4762-8f3b-27b59c571a36">

# TASK 26 :- 👇
## TITLE :- `logged-in page opened through your deployment.`
<img width="1434" alt="deployed_loggedin" src="https://github.com/Uday-Pratap-hub/IBM-Full-Stack-Application-Development-Capstone-Project/assets/67860426/1902799f-6872-401c-80a4-a0167d975035">

# TASK 27 :- 👇
## TITLE :- `dealer details page opened through your deployment.`
<img width="1431" alt="deployed_dealer_detail" src="https://github.com/Uday-Pratap-hub/IBM-Full-Stack-Application-Development-Capstone-Project/assets/67860426/7f9911a6-5f8d-4eb7-9843-005d9995c1fe">

# TASK 28 :- 👇
## TITLE :- `of a review added through your deployed application.`
<img width="1428" alt="deployed_add_review" src="https://github.com/Uday-Pratap-hub/IBM-Full-Stack-Application-Development-Capstone-Project/assets/67860426/3a113086-3ef2-4782-a6d8-c0c8e338c12f">

# So now SUBMIT your Assignment. ✅ 😇
## After Submitting do the Peer-Reviewing as mentioned in the Video... 👇 ✅
https://github.com/Uday-Pratap-hub/IBM-Full-Stack-Application-Development-Capstone-Project/assets/67860426/0f387dfc-7837-466c-8da3-436c019694ca

# So your course is completed NOW.. Go and collect your Certificates NOW... ✅ 😇 😎 🚀
